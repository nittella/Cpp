#pragma once

#include "test_runner.h"

void TestAdd();

void TestDel();

void TestFind();

void TestLast();
