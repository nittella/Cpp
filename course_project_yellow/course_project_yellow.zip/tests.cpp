#include "tests.h"

void TestAdd(){
    // add to empty

};

void TestDel();

void TestFind();

void TestLast();